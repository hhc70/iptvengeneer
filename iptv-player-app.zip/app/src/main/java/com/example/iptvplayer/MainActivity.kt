package com.example.iptvplayer

import android.app.PictureInPictureParams
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.Button
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : ComponentActivity() {
    private val viewModel by viewModels<MainViewModel>()

    private val openPlaylistFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            viewModel.loadPlaylistFromUri(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            IPTVPlayerTheme {
                val state by viewModel.uiState.collectAsStateWithLifecycle()

                Surface(modifier = Modifier.fillMaxSize()) {
                    AppScreen(
                        state = state,
                        onPlaylistUrlChange = viewModel::updatePlaylistUrl,
                        onLoadUrl = viewModel::loadPlaylistFromUrl,
                        onOpenFile = { openPlaylistFile.launch(arrayOf("*/*")) },
                        onSelectChannel = viewModel::selectChannel,
                        onToggleFavorite = viewModel::toggleFavorite,
                        onToggleFavoritesFilter = viewModel::toggleFavoritesFilter,
                        onSearch = viewModel::updateSearch,
                        onEnterPip = { enterPip() }
                    )
                }
            }
        }
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Optional behavior for phone/tablet. On TV, user-initiated PiP is more predictable via the button.
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
    }
}

@Composable
private fun AppScreen(
    state: MainUiState,
    onPlaylistUrlChange: (String) -> Unit,
    onLoadUrl: () -> Unit,
    onOpenFile: () -> Unit,
    onSelectChannel: (Channel) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onToggleFavoritesFilter: () -> Unit,
    onSearch: (String) -> Unit,
    onEnterPip: () -> Unit
) {
    val selected = state.selectedChannel

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .width(360.dp)
                .fillMaxHeight()
        ) {
            PlaylistControls(
                state = state,
                onPlaylistUrlChange = onPlaylistUrlChange,
                onLoadUrl = onLoadUrl,
                onOpenFile = onOpenFile,
                onToggleFavoritesFilter = onToggleFavoritesFilter,
                onSearch = onSearch
            )

            Spacer(Modifier.height(12.dp))

            ChannelList(
                channels = state.visibleChannels,
                favoriteIds = state.favoriteIds,
                selectedChannelId = selected?.id,
                onSelectChannel = onSelectChannel,
                onToggleFavorite = onToggleFavorite
            )
        }

        Spacer(Modifier.width(16.dp))

        Column(modifier = Modifier.fillMaxSize()) {
            PlayerPane(
                channel = selected,
                onEnterPip = onEnterPip
            )
            state.error?.let {
                Spacer(Modifier.height(12.dp))
                Text(text = it, color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
private fun PlaylistControls(
    state: MainUiState,
    onPlaylistUrlChange: (String) -> Unit,
    onLoadUrl: () -> Unit,
    onOpenFile: () -> Unit,
    onToggleFavoritesFilter: () -> Unit,
    onSearch: (String) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Playlist", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(
                value = state.playlistUrl,
                onValueChange = onPlaylistUrlChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("M3U URL") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onLoadUrl) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Load URL")
                }
                TextButton(onClick = onOpenFile) {
                    Icon(Icons.Default.FolderOpen, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Open file")
                }
            }

            OutlinedTextField(
                value = state.searchQuery,
                onValueChange = onSearch,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Search channels") },
                singleLine = true
            )

            FilterChip(
                selected = state.onlyFavorites,
                onClick = onToggleFavoritesFilter,
                label = { Text(if (state.onlyFavorites) "Showing favorites" else "All channels") }
            )

            if (state.isLoading) {
                CircularProgressIndicator()
            } else {
                Text("${state.visibleChannels.size} channels")
            }
        }
    }
}

@Composable
private fun ChannelList(
    channels: List<Channel>,
    favoriteIds: Set<String>,
    selectedChannelId: String?,
    onSelectChannel: (Channel) -> Unit,
    onToggleFavorite: (String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(20.dp)
    ) {
        if (channels.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Load an M3U playlist to see channels.")
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize().padding(10.dp)) {
                items(channels, key = { it.id }) { channel ->
                    ChannelRow(
                        channel = channel,
                        selected = channel.id == selectedChannelId,
                        isFavorite = channel.id in favoriteIds,
                        onClick = { onSelectChannel(channel) },
                        onToggleFavorite = { onToggleFavorite(channel.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ChannelRow(
    channel: Channel,
    selected: Boolean,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    var focused by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .background(
                when {
                    selected -> MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
                    focused -> MaterialTheme.colorScheme.surfaceVariant
                    else -> Color.Transparent
                },
                RoundedCornerShape(16.dp)
            )
            .border(
                width = if (focused) 1.dp else 0.dp,
                color = if (focused) MaterialTheme.colorScheme.primary else Color.Transparent,
                shape = RoundedCornerShape(16.dp)
            )
            .onFocusChanged { focused = it.isFocused }
            .focusable()
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(channel.name, style = MaterialTheme.typography.titleMedium)
            channel.group?.takeIf { it.isNotBlank() }?.let {
                Spacer(Modifier.height(2.dp))
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        IconButton(onClick = onToggleFavorite) {
            Icon(
                imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = "Favorite"
            )
        }
    }
}

@Composable
private fun PlayerPane(
    channel: Channel?,
    onEnterPip: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF101317)),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = channel?.name ?: "No channel selected",
                        style = MaterialTheme.typography.headlineSmall
                    )
                    channel?.group?.let {
                        Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                IconButton(
                    onClick = onEnterPip,
                    enabled = channel != null
                ) {
                    Icon(Icons.Default.PictureInPictureAlt, contentDescription = "Picture in Picture")
                }
            }

            Spacer(Modifier.height(12.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16 / 9f)
                    .background(Color.Black, RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (channel == null) {
                    Text("Choose a channel to start playback.")
                } else {
                    ExoPlayerView(streamUrl = channel.url)
                }
            }
        }
    }
}

@Composable
private fun ExoPlayerView(streamUrl: String) {
    val context = LocalContext.current
    val player = remember(context, streamUrl) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(streamUrl))
            prepare()
            playWhenReady = true
        }
    }

    DisposableEffect(player) {
        onDispose { player.release() }
    }

    AndroidView(
        factory = {
            PlayerView(it).apply {
                this.player = player
                useController = true
                setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            }
        },
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
private fun IPTVPlayerTheme(content: @Composable () -> Unit) {
    val colors = darkColorScheme(
        background = Color(0xFF0B0D10),
        surface = Color(0xFF12161B),
        surfaceVariant = Color(0xFF1A2027),
        primary = Color(0xFF7C9DFF),
        secondary = Color(0xFF9FD3C7)
    )
    MaterialTheme(
        colorScheme = colors,
        content = content
    )
}
