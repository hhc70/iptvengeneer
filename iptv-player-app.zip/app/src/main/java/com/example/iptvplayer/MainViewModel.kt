package com.example.iptvplayer

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class MainUiState(
    val playlistUrl: String = "",
    val channels: List<Channel> = emptyList(),
    val selectedChannel: Channel? = null,
    val favoriteIds: Set<String> = emptySet(),
    val onlyFavorites: Boolean = false,
    val searchQuery: String = "",
    val isLoading: Boolean = false,
    val error: String? = null
) {
    val visibleChannels: List<Channel>
        get() {
            val source = if (onlyFavorites) {
                channels.filter { it.id in favoriteIds }
            } else channels

            if (searchQuery.isBlank()) return source
            return source.filter { it.name.contains(searchQuery, ignoreCase = true) }
        }
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = PlaylistRepository(application)
    private val favoritesStore = FavoritesStore(application)

    private val mutableState = MutableStateFlow(MainUiState())

    val uiState: StateFlow<MainUiState> = combine(
        mutableState,
        favoritesStore.favorites
    ) { state, favorites ->
        state.copy(favoriteIds = favorites)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), MainUiState())

    fun updatePlaylistUrl(url: String) {
        mutableState.value = mutableState.value.copy(playlistUrl = url)
    }

    fun updateSearch(query: String) {
        mutableState.value = mutableState.value.copy(searchQuery = query)
    }

    fun toggleFavoritesFilter() {
        val current = mutableState.value.onlyFavorites
        mutableState.value = mutableState.value.copy(onlyFavorites = !current)
    }

    fun selectChannel(channel: Channel) {
        mutableState.value = mutableState.value.copy(selectedChannel = channel)
    }

    fun toggleFavorite(channelId: String) {
        viewModelScope.launch {
            favoritesStore.toggle(channelId)
        }
    }

    fun loadPlaylistFromUrl() {
        val url = mutableState.value.playlistUrl.trim()
        if (url.isBlank()) {
            mutableState.value = mutableState.value.copy(error = "Enter a playlist URL first.")
            return
        }

        viewModelScope.launch {
            mutableState.value = mutableState.value.copy(isLoading = true, error = null)
            val result = repo.loadFromUrl(url)
            mutableState.value = result.fold(
                onSuccess = { list ->
                    mutableState.value.copy(
                        isLoading = false,
                        channels = list,
                        selectedChannel = list.firstOrNull(),
                        error = if (list.isEmpty()) "No channels found in this playlist." else null
                    )
                },
                onFailure = { error ->
                    mutableState.value.copy(
                        isLoading = false,
                        error = error.message ?: "Failed to load playlist."
                    )
                }
            )
        }
    }

    fun loadPlaylistFromUri(uri: Uri) {
        viewModelScope.launch {
            mutableState.value = mutableState.value.copy(isLoading = true, error = null)
            val result = repo.loadFromUri(uri)
            mutableState.value = result.fold(
                onSuccess = { list ->
                    mutableState.value.copy(
                        isLoading = false,
                        channels = list,
                        selectedChannel = list.firstOrNull(),
                        error = if (list.isEmpty()) "No channels found in this playlist." else null
                    )
                },
                onFailure = { error ->
                    mutableState.value.copy(
                        isLoading = false,
                        error = error.message ?: "Failed to load playlist."
                    )
                }
            )
        }
    }
}
