package com.example.iptvplayer

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URL

class PlaylistRepository(private val context: Context) {

    suspend fun loadFromUrl(url: String): Result<List<Channel>> = withContext(Dispatchers.IO) {
        runCatching {
            val content = URL(url).readText()
            M3uParser.parse(content)
        }
    }

    suspend fun loadFromUri(uri: Uri): Result<List<Channel>> = withContext(Dispatchers.IO) {
        runCatching {
            val content = context.contentResolver.openInputStream(uri)
                ?.bufferedReader()
                ?.use { it.readText() }
                ?: error("Unable to read playlist")
            M3uParser.parse(content)
        }
    }
}
