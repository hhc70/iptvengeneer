package com.example.iptvplayer

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "favorites")

class FavoritesStore(private val context: Context) {
    private val favoritesKey = stringSetPreferencesKey("favorite_channel_ids")

    val favorites: Flow<Set<String>> = context.dataStore.data.map { prefs ->
        prefs[favoritesKey].orEmpty()
    }

    suspend fun toggle(channelId: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[favoritesKey].orEmpty().toMutableSet()
            if (!current.add(channelId)) current.remove(channelId)
            prefs[favoritesKey] = current
        }
    }
}
